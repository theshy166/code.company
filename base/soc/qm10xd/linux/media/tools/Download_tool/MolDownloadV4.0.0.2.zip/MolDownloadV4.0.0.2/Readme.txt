﻿【MolDownload.exe.config 界面未提供的配置信息】

01. 串口模式响应超时时间：单位毫秒
<setting name="SerialPortResponseTimeout" serializeAs="String">
    <value>1500</value>
</setting>

02. 串口模式握手命令重发间隔：单位毫秒
<setting name="SerialPortHandshakeInterval" serializeAs="String">
    <value>10</value>
</setting>

03. TFTP 模式检查 Uboot 状态的请求命令：填写表示检查，不填写则表示不检查
<setting name="BoardRequestCheckUboot" serializeAs="String">
    <value>Hit any key to stop autoboot</value>
</setting>

04. TFTP 模式响应超时时间：单位毫秒
<setting name="BoardResponseTimeout" serializeAs="String">
    <value>60000</value>
</setting>

[注]：
     1. 以上配置一般为研发人员修改，普通用户无需修改。
     2. 其余未说明的配置要么在界面上提供并配说明，要么不可以修改。

--------------------------------------------------------------------------------

【DownloadConfig.json】
默认配置文件，在 Config 目录下，JSON 格式，举例说明如下：
Version：版本号，不可编辑
UartProjects：串口项目列表，不可编辑
TftpNorProjects：TFTP NOR 项目列表，不可编辑
TftpNandProjects：TFTP NAND 项目列表，不可编辑
TftpNandProjects：TFTP EMMC 项目列表，不可编辑
Name：项目名，可编辑
StartAddressLength：起始地址长度，十进制，可编辑，单位字节，默认为 4
Files：文件列表，不可编辑
FileType：文件类型，PDL、SDL、自定义之一，可编辑，仅串口模式用
FileId：文件 ID，可编辑，仅串口模式用
FileName：文件名，不含路径，可编辑
StartAddress：起始地址，十六进制，可编辑
FlashAddress：Flash 地址，十六进制，可编辑，仅 TFTP 模式用
EmmcAddress：EMMC 地址，十六进制，可编辑，仅 TFTP 模式用
FillMemoryValue：填充内存值，可编辑，仅 TFTP 模式用
SpiInfo：SPI 信息，可编辑，仅 TFTP NOR 模式用
Selected：true=下载，false=不需要下载，可编辑；串口模式下 FileType 为 PDL、SDL 时 Selected 必须为 true，TFTP 模式下 PDL、SDL 不做必选要求
文件可以使用相对路径（相对应配置文件的路径）或绝对路径。
{
  "Version": 4,
  "UartProjects": [
    {
      "Name": "FY10",
      "StartAddressLength": 4,
      "Files": [
        {
          "FileType": "PDL",
          "FileId": 0,
          "FileName": "FY10\\boot1\\u-boot-pdl-header.img",
          "StartAddress": "0x38b00000",
          "Selected": true
        },
        {
          "FileType": "SDL",
          "FileId": 0,
          "FileName": "FY10\\boot1\\u-boot-sdl.bin",
          "StartAddress": "0x80000000",
          "Selected": true
        },
        {
          "FileType": "IMG",
          "FileId": 1,
          "FileName": "FY10\\boot1\\u-boot-with-spl.img",
          "StartAddress": "0x81000000",
          "Selected": true
        }
      ]
    },
    {
      "Name": "FY10D",
      "StartAddressLength": 4,
      "Files": [
        {
          "FileType": "PDL",
          "FileId": 0,
          "FileName": "FY10d\\boot\\u-boot-pdl-header.img",
          "StartAddress": "0x34100000",
          "Selected": true
        },
        {
          "FileType": "SDL",
          "FileId": 0,
          "FileName": "FY10d\\boot\\u-boot-sdl.bin",
          "StartAddress": "0x40000000",
          "Selected": true
        },
        {
          "FileType": "IMG",
          "FileId": 1,
          "FileName": "FY10d\\boot\\u-boot-with-spl.img",
          "StartAddress": "0x41000000",
          "Selected": true
        }
      ]
    },
    {
      "Name": "FY00",
      "StartAddressLength": 4,
      "Files": [
        {
          "FileType": "PDL",
          "FileId": 0,
          "FileName": "FY00\\boot\\u-boot-pdl-header.img",
          "StartAddress": "0x34100000",
          "Selected": true
        },
        {
          "FileType": "SDL",
          "FileId": 0,
          "FileName": "FY00\\boot\\u-boot-sdl.bin",
          "StartAddress": "0x40000000",
          "Selected": true
        },
        {
          "FileType": "IMG",
          "FileId": 1,
          "FileName": "FY00\\boot\\u-boot-with-spl.img",
          "StartAddress": "0x41000000",
          "Selected": true
        }
      ]
    },
    {
      "Name": "FY02",
      "StartAddressLength": 4,
      "Files": [
        {
          "FileType": "PDL",
          "FileId": 0,
          "FileName": "FY02\\boot\\u-boot-pdl-header.img",
          "StartAddress": "0x38a00000",
          "Selected": true
        },
        {
          "FileType": "SDL",
          "FileId": 0,
          "FileName": "FY02\\boot\\u-boot-sdl.bin",
          "StartAddress": "0x40000000",
          "Selected": true
        },
        {
          "FileType": "IMG",
          "FileId": 1,
          "FileName": "FY02\\boot\\u-boot-with-spl.img",
          "StartAddress": "0x41000000",
          "Selected": true
        }
      ]
    }
  ],
  "TftpNorProjects": [
    {
      "Name": "FY10",
      "StartAddressLength": 4,
      "FlashAddressLength": 4,
      "Files": [
        {
          "FileName": "FY10\\kernel\\zImage-dtb",
          "StartAddress": "0x81000000",
          "FlashAddress": "0x80000",
          "FillMemoryValue": 255,
          "SpiInfo": 0,
          "Selected": true
        },
        {
          "FileName": "FY10\\kernel\\molchip.dtb",
          "StartAddress": "0x81000000",
          "FlashAddress": "0xa80000",
          "FillMemoryValue": 255,
          "SpiInfo": 0,
          "Selected": true
        }
      ]
    },
    {
      "Name": "FY10D",
      "StartAddressLength": 4,
      "FlashAddressLength": 4,
      "Files": [
        {
          "FileName": "FY10d\\kernel\\zImage",
          "StartAddress": "0x41000000",
          "FlashAddress": "0xA0000",
          "FillMemoryValue": 255,
          "SpiInfo": 0,
          "Selected": true
        },
        {
          "FileName": "FY10d\\kernel\\molchip-kernel.dtb",
          "StartAddress": "0x41000000",
          "FlashAddress": "0xAA0000",
          "FillMemoryValue": 255,
          "SpiInfo": 0,
          "Selected": true
        }
      ]
    },
    {
      "Name": "FY00",
      "StartAddressLength": 4,
      "FlashAddressLength": 4,
      "Files": [
        {
          "FileName": "FY00\\kernel\\zImage",
          "StartAddress": "0x41000000",
          "FlashAddress": "0xA0000",
          "FillMemoryValue": 255,
          "SpiInfo": 0,
          "Selected": true
        },
        {
          "FileName": "FY00\\kernel\\molchip-kernel.dtb",
          "StartAddress": "0x41000000",
          "FlashAddress": "0xaA0000",
          "FillMemoryValue": 255,
          "SpiInfo": 0,
          "Selected": true
        }
      ]
    },
    {
      "Name": "FY02",
      "StartAddressLength": 4,
      "FlashAddressLength": 4,
      "Files": [
        {
          "FileName": "FY02\\kernel\\zImage",
          "StartAddress": "0x41000000",
          "FlashAddress": "0xA0000",
          "FillMemoryValue": 255,
          "SpiInfo": 0,
          "Selected": true
        },
        {
          "FileName": "FY02\\kernel\\molchip-v2p-chip-fy02.dtb",
          "StartAddress": "0x41000000",
          "FlashAddress": "0xAA0000",
          "FillMemoryValue": 255,
          "SpiInfo": 0,
          "Selected": true
        }
      ]
    }
  ],
  "TftpNandProjects": [
    {
      "Name": "FY10",
      "StartAddressLength": 4,
      "FlashAddressLength": 4,
      "Files": [
        {
          "FileName": "FY10\\kernel\\zImage",
          "StartAddress": "0x81000000",
          "FlashAddress": "0x80000",
          "FillMemoryValue": 255,
          "Selected": true
        },
        {
          "FileName": "FY10\\kernel\\molchip.dtb",
          "StartAddress": "0x81000000",
          "FlashAddress": "0xa80000",
          "FillMemoryValue": 255,
          "Selected": true
        }
      ]
    },
    {
      "Name": "FY10D",
      "StartAddressLength": 4,
      "FlashAddressLength": 4,
      "Files": [
        {
          "FileName": "FY10D\\kernel\\zImage",
          "StartAddress": "0x41000000",
          "FlashAddress": "0xA0000",
          "FillMemoryValue": 255,
          "Selected": true
        },
        {
          "FileName": "FY10D\\kernel\\molchip-kernel.dtb",
          "StartAddress": "0x41000000",
          "FlashAddress": "0xAA0000",
          "FillMemoryValue": 255,
          "Selected": true
        }
      ]
    },
    {
      "Name": "FY02",
      "StartAddressLength": 4,
      "FlashAddressLength": 4,
      "Files": [
        {
          "FileName": "FY02\\kernel\\zImage",
          "StartAddress": "0x41000000",
          "FlashAddress": "0xA0000",
          "FillMemoryValue": 255,
          "Selected": true
        },
        {
          "FileName": "FY02\\kernel\\molchip-v2p-chip-fy02.dtb",
          "StartAddress": "0x41000000",
          "FlashAddress": "0xAA0000",
          "FillMemoryValue": 255,
          "Selected": true
        }
      ]
    }
  ],
  "TftpEmmcProjects": [
    {
      "Name": "FY10",
      "StartAddressLength": 4,
      "EmmcAddressLength": 4,
      "Files": [
        {
          "FileName": "FY10\\kernel\\zImage",
          "StartAddress": "0x81000000",
          "EmmcAddress": "0x80000",
          "FillMemoryValue": 255,
          "Selected": true
        },
        {
          "FileName": "FY10\\kernel\\molchip.dtb",
          "StartAddress": "0x81000000",
          "EmmcAddress": "0xa80000",
          "FillMemoryValue": 255,
          "Selected": true
        }
      ]
    },
    {
      "Name": "FY10D",
      "StartAddressLength": 4,
      "EmmcAddressLength": 4,
      "Files": [
        {
          "FileName": "FY10D\\kernel\\zImage",
          "StartAddress": "0x41000000",
          "EmmcAddress": "0xA0000",
          "FillMemoryValue": 255,
          "Selected": true
        },
        {
          "FileName": "FY10D\\kernel\\molchip-kernel.dtb",
          "StartAddress": "0x41000000",
          "EmmcAddress": "0xAA0000",
          "FillMemoryValue": 255,
          "Selected": true
        }
      ]
    },
    {
      "Name": "FY02",
      "StartAddressLength": 4,
      "EmmcAddressLength": 4,
      "Files": [
        {
          "FileName": "FY02\\kernel\\zImage",
          "StartAddress": "0x41000000",
          "EmmcAddress": "0xA0000",
          "FillMemoryValue": 255,
          "Selected": true
        },
        {
          "FileName": "FY02\\kernel\\molchip-v2p-chip-fy02.dtb",
          "StartAddress": "0x41000000",
          "EmmcAddress": "0xAA0000",
          "FillMemoryValue": 255,
          "Selected": true
        }
      ]
    }
  ]
}